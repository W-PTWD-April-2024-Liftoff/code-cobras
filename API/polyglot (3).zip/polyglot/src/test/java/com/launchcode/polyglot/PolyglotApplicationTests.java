package com.launchcode.polyglot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolyglotApplicationTests {

	@Test
	void contextLoads() {
	}

}
